v1.0.2
==============
**Date:** 05-May-2015

- (enh #1): Remove not needed files by clearing iccprofiles/CMYK folder.

v1.0.1
==============
**Date:** 18-Feb-2015

- Upgrade to latest archive of mPDF 6.0

Initial Release
===============
**Date:** 28-Dec-2014

- mPDF 6.0

Refer the [CHANGE LOG Text version](https://github.com/kartik-v/mpdf/blob/master/CHANGELOG.txt) for more details.
