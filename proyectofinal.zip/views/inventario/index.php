<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Inventario';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <div class="jumbotron">
    <h1><?= Html::encode($this->title) ?></h1>
    </div>

    <p>
        Aquí va el inventario
    </p>

    <code><?= __FILE__ ?></code>
</div>

