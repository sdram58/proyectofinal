<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=192.168.1.250;dbname=yii2base',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];
