<?php

return [
    'adminEmail' => 'cartatar@gmail.com',
];
