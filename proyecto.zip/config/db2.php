<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=185.28.20.10;dbname=u608729532_conta',
    'username' => 'u608729532_conta',
    'password' => 'contapass',
    'charset' => 'utf8',
];
/*
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=192.168.1.250;dbname=contabilidad',
    'username' => 'contabilidad',
    'password' => 'contaP4SS',
    'charset' => 'utf8',
];
*/