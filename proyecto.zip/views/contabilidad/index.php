<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Contabilidad';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        Aquí va la contabilidad
    </p>

    <code><?= __FILE__ ?></code>
</div>