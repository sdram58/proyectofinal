<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Codigos */
$descripcion = ($model->descripcionc=='')?$model->decripcionv:$model->descripcionc;
$this->title = 'Actualizar Codigo: '.$descripcion;
$this->params['breadcrumbs'][] = ['label' => 'Codigos', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Actualizar';
?>
<div class="codigos-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
