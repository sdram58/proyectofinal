<?php use yii\helpers\Html;?>
<?= Html::encode($mensaje)?>
<?php echo '<br>'.Yii::$app->db->dsn;?>